"""MCP servers for Empirica (Semantic Self-Aware Kit)."""
